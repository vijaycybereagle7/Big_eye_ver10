import { createClient } from '@supabase/supabase-js'

const supabaseUrl = "https://nlqqbxnifyyvibxboufb.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5scXFieG5pZnl5dmlieGJvdWZiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3MDU5MzksImV4cCI6MjA3NzI4MTkzOX0.xI6SZdk6j3jz1QoqwoyEyc8Vi6uGsGwQH1cVfLpFaYQ";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
